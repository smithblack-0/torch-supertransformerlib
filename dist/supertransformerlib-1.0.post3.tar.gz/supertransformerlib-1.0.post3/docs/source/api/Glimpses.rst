Glimpses
========

Documentation for the glimpses kernel library

.. automodule:: Glimpses

view
----

.. autoclass:: view

reshape
-------

.. autoclass:: reshape

local
-----

.. autofunction:: local

dilocal
-------

.. autofunction:: dilocal
