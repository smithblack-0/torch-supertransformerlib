Loss
====

Ensemble enabled loss functions

.. automodule:: Loss


CrossEntropyEnsembleBoost
-------------------------

.. autoclass:: CrossEntropyEnsembleBoost

CrossEntropyAdditiveBoost
-------------------------

.. autoclass:: CrossEntropyAdditiveBoost

