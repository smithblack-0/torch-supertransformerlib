Linear
======

.. automodule:: Linear

.. autoclass:: Linear