API
===

This section contains the information
on the api. The primary library
is found in Attention. Auxilary functions
are found in Glimpses, Loss, and Linear


.. toctree::
    Attention
    Glimpses
    Loss
    Linear


