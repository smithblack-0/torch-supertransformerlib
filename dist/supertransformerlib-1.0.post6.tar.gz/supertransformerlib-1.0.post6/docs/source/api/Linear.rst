Linear
======

.. automodule:: supertransformerlib.Linear

.. autoclass:: Linear