Loss
====

Ensemble enabled loss functions

.. automodule:: supertransformerlib.Loss


CrossEntropyEnsembleBoost
-------------------------

.. autoclass:: CrossEntropyEnsembleBoost

CrossEntropyAdditiveBoost
-------------------------

.. autoclass:: CrossEntropyAdditiveBoost

